package main

import "fmt"

func MergeSlices[T any](slice1 []T, slice2 []T) []T {
	mergedSlice := append(slice1, slice2...)
	return mergedSlice
}

func main() {
	intSlice1 := []int{1, 2, 3}
	intSlice2 := []int{4, 5, 6}
	mergedIntSlice := MergeSlices(intSlice1, intSlice2)
	fmt.Println("Hasil penggabungan slice int:")
	fmt.Println(mergedIntSlice)

	strSlice1 := []string{"apple", "banana"}
	strSlice2 := []string{"orange", "grape"}
	mergedStrSlice := MergeSlices(strSlice1, strSlice2)
	fmt.Println("Hasil penggabungan slice string:")
	fmt.Println(mergedStrSlice)
}
