package main

import "fmt"

type Product[T any] struct {
	Name  string
	Price int
	Data  T
}

func (p Product[T]) PrintProductInfo() {
	fmt.Printf("Product Name: %s\n", p.Name)
	fmt.Printf("Product Price: %d\n", p.Price)
	fmt.Printf("Product Data: %+v\n", p.Data)
}

type Food struct {
	ExpiryDate string
}

type Electronics struct {
	ModelNumber string
}

func main() {
	foodProduct := Product[Food]{
		Name:  "Chips",
		Price: 10,
		Data:  Food{ExpiryDate: "2023-12-31"},
	}

	electronicsProduct := Product[Electronics]{
		Name:  "Laptop",
		Price: 800,
		Data:  Electronics{ModelNumber: "ABC123"},
	}

	fmt.Println("Informasi Produk Makanan:")
	foodProduct.PrintProductInfo()

	fmt.Println("Informasi Produk Elektronik:")
	electronicsProduct.PrintProductInfo()
}
